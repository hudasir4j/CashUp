const revealedNotification = querySelector('.mystery-notif');
var hasBeenClicked = false;
const button = document.querySelector(".button");

button.addEventListener('click', appear);


if (hasBeenClicked==true) {
  revealedNotification.style.display='block';
}

function appear(hasBeenClicked){
  hasBeenClicked=true;
}

