const moneyButton = document.querySelector('.moneyButton');

moneyButton.addEventListener('click', clearInput);

function clearInput(){
      var getValue= document.querySelector('.entry');
      var getValue1 = document.querySelector('.entry1');
        if (getValue.value !="") {
            getValue.value = "";
            getValue1.value= "";
        }
 }